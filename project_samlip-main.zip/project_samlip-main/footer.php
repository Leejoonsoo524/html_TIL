<footer>
    <div class="ft_top">
        <div class="menu">
            <a href="#">개인정보처리방침</a>
            <a href="#">영상정보처리기기 운영관리방침</a>
            <a href="#">거래희망회사 사전등록</a>
            <a href="#">동반성장</a>
            <a href="#"><img src="./images/ft_ccm.png" alt="소비자중심CCM"></a>
        </div>
        <ul class="site_all">
            <li><p>FAMILY SITES</p><!-- 화살표 bg -->
                <ul class="family_list">
                    <li><a href="#">PALIS BAGUETEE</a></li>
                    <li><a href="#">PALIS BAGUETEE</a></li>
                    <li><a href="#">PALIS BAGUETEE</a></li>
                    <li><a href="#">PALIS BAGUETEE</a></li>
                    <li><a href="#">PALIS BAGUETEE</a></li>
                    <li><a href="#">PALIS BAGUETEE</a></li>
                    <li><a href="#">PALIS BAGUETEE</a></li>
                    <li><a href="#">PALIS BAGUETEE</a></li>
                    <li><a href="#">PALIS BAGUETEE</a></li>
                    <li><a href="#">PALIS BAGUETEE</a></li>
                </ul>
            </li>
            <li><p>SITE MAP</p>
                <div class="sitemap_wrap"><!-- bg -->
                    <div class="sitemap_contents">
                        <h2>Sitemap</h2>
                        <button type="button" class="close">X</button>
                        <!-- 사이트맵 목록 작성위치 -->
                    </div>
                </div>
            </li>
        </ul>
    </div>
    <div class="ft_btm">
        <address>Customer Service  전화번호 080-739-8572 (월~금 09:00~17:00)<br>
            101, Gongdan 1-daero, Siheung-si, Gyeonggi-do, Republic of Korea ㈜SPC삼립 대표이사 황종현</address>
        <p>&copy; SPC Samlip. All rights reserved.</p>
    </div>
</footer>